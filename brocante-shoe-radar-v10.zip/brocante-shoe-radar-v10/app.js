import { pipeline } from "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3/+esm";

const $ = (id) => document.getElementById(id);

const video = $("camera");
const overlay = $("overlay");
const octx = overlay.getContext("2d");
const frame = $("frame");
const fctx = frame.getContext("2d", { willReadFrequently: true });
const cropCanvas = document.createElement("canvas");
const cctx = cropCanvas.getContext("2d", { willReadFrequently: true });

let stream = null;
let detector = null;
let classifier = null;
let scanning = false;
let paused = false;
let scanTimer = null;
let scanNumber = 0;
let detectionTotal = 0;
let classifiedTotal = 0;
let alertTotal = 0;
let torchOn = false;
let audioCtx = null;

const streaks = new Map();
const lastAlerts = new Map();
const recentDetections = [];
const ALERT_COOLDOWN_MS = 6500;

const BRANDS = [
  { key: "salomon", label: "Salomon", prompt: "Salomon technical trail running shoe" },
  { key: "merrell", label: "Merrell", prompt: "Merrell hiking trail shoe" },
  { key: "hoka", label: "Hoka", prompt: "Hoka trail running shoe" },
  { key: "la sportiva", label: "La Sportiva", prompt: "La Sportiva technical trail shoe" },
  { key: "adidas terrex", label: "Adidas Terrex", prompt: "Adidas Terrex hiking trail shoe" },
  { key: "scarpa", label: "Scarpa", prompt: "Scarpa hiking trail shoe" }
];

const FALLBACK_CLASSES = [
  { key: "generic hiking", label: "Randonnée", prompt: "technical hiking shoe or hiking boot", kind: "generic" },
  { key: "generic trail", label: "Trail", prompt: "technical trail running shoe", kind: "generic" },
  { key: "casual", label: "Sneaker classique", prompt: "ordinary casual fashion sneaker", kind: "negative" },
  { key: "other footwear", label: "Autre chaussure", prompt: "ordinary non outdoor footwear", kind: "negative" }
];

function settings() {
  const watched = new Set([...document.querySelectorAll(".watch-brand:checked")].map(x => x.value));
  return {
    watched,
    hiking: $("watch-hiking").checked,
    trail: $("watch-trail").checked,
    genericAlert: $("generic-alert").checked,
    detectorThreshold: Number($("threshold").value),
    brandThreshold: Number($("brand-threshold").value),
    brandMargin: Number($("brand-margin").value),
    interval: Number($("interval").value),
    confirmFrames: Number($("confirm-frames").value),
    maxCrops: Number($("max-crops").value),
    sound: $("sound").checked,
    vibration: $("vibration").checked,
    boxes: $("boxes").checked,
  };
}

function saveSettings() {
  const data = {
    brands: [...document.querySelectorAll(".watch-brand")].reduce((a, x) => (a[x.value] = x.checked, a), {}),
    hiking: $("watch-hiking").checked,
    trail: $("watch-trail").checked,
    genericAlert: $("generic-alert").checked,
    detectorThreshold: $("threshold").value,
    brandThreshold: $("brand-threshold").value,
    brandMargin: $("brand-margin").value,
    interval: $("interval").value,
    confirmFrames: $("confirm-frames").value,
    maxCrops: $("max-crops").value,
    sound: $("sound").checked,
    vibration: $("vibration").checked,
    boxes: $("boxes").checked,
  };
  localStorage.setItem("brocante-radar-settings-v10", JSON.stringify(data));
}

function loadSettings() {
  let d = {};
  try {
    d = JSON.parse(
      localStorage.getItem("brocante-radar-settings-v10") ||
      localStorage.getItem("brocante-radar-settings-v9") || "{}"
    );
  } catch {}

  document.querySelectorAll(".watch-brand").forEach(x => {
    if (d.brands && x.value in d.brands) x.checked = !!d.brands[x.value];
  });
  if ("hiking" in d) $("watch-hiking").checked = d.hiking;
  if ("trail" in d) $("watch-trail").checked = d.trail;
  if ("genericAlert" in d) $("generic-alert").checked = d.genericAlert;
  $("threshold").value = d.detectorThreshold || d.threshold || "0.07";
  $("brand-threshold").value = d.brandThreshold || "0.34";
  $("brand-margin").value = d.brandMargin || "0.07";
  $("interval").value = d.interval || "1500";
  $("confirm-frames").value = d.confirmFrames || "2";
  $("max-crops").value = d.maxCrops || "2";
  if ("sound" in d) $("sound").checked = d.sound;
  if ("vibration" in d) $("vibration").checked = d.vibration;
  if ("boxes" in d) $("boxes").checked = d.boxes;
  updateSettingLabels();
}

function updateSettingLabels() {
  $("threshold-value").textContent = Number($("threshold").value).toFixed(2).replace(".", ",");
  $("brand-threshold-value").textContent = Number($("brand-threshold").value).toFixed(2).replace(".", ",");
  $("brand-margin-value").textContent = Number($("brand-margin").value).toFixed(2).replace(".", ",");
  $("interval-value").textContent = `${(Number($("interval").value) / 1000).toFixed(2).replace(".", ",")} s`;
}

function classifierCandidates() {
  const s = settings();
  const classes = BRANDS.filter(x => s.watched.has(x.key)).map(x => ({...x, kind:"brand"}));
  if (s.hiking) classes.push(FALLBACK_CLASSES[0]);
  if (s.trail) classes.push(FALLBACK_CLASSES[1]);
  classes.push(FALLBACK_CLASSES[2], FALLBACK_CLASSES[3]);
  return classes;
}

async function ensureAudio() {
  if (audioCtx) return;
  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    await audioCtx.resume();
  } catch {}
}

function beep(priority = true) {
  if (!settings().sound || !audioCtx) return;
  try {
    const osc = audioCtx.createOscillator(), gain = audioCtx.createGain();
    osc.type = "sine";
    osc.frequency.value = priority ? 1160 : 760;
    gain.gain.setValueAtTime(0.0001, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(priority ? 0.22 : 0.10, audioCtx.currentTime + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.22);
    osc.connect(gain).connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.24);
  } catch {}
}

function vibrate(priority = true) {
  if (!settings().vibration || !navigator.vibrate) return;
  navigator.vibrate(priority ? [120, 60, 160] : 90);
}

function setState(main, sub, pausedState = false) {
  $("state").textContent = main;
  $("scan-info").textContent = sub;
  $("live-dot").classList.toggle("paused", pausedState);
}

function resizeOverlay() {
  const rect = video.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2);
  overlay.width = Math.round(rect.width * dpr);
  overlay.height = Math.round(rect.height * dpr);
  octx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function captureFrame() {
  const vw = video.videoWidth, vh = video.videoHeight;
  if (!vw || !vh) return null;
  const maxW = 640, scale = Math.min(1, maxW / vw);
  frame.width = Math.max(1, Math.round(vw * scale));
  frame.height = Math.max(1, Math.round(vh * scale));
  fctx.drawImage(video, 0, 0, frame.width, frame.height);
  return frame.toDataURL("image/jpeg", 0.76);
}

function area(box) {
  return Math.max(0, box.xmax-box.xmin) * Math.max(0, box.ymax-box.ymin);
}

function iou(a,b) {
  const x1=Math.max(a.xmin,b.xmin), y1=Math.max(a.ymin,b.ymin);
  const x2=Math.min(a.xmax,b.xmax), y2=Math.min(a.ymax,b.ymax);
  const inter=Math.max(0,x2-x1)*Math.max(0,y2-y1);
  const union=area(a)+area(b)-inter;
  return union>0?inter/union:0;
}

function dedupeBoxes(rows) {
  const sorted=[...rows].sort((a,b)=>b.score-a.score);
  const keep=[];
  for (const r of sorted) {
    if (area(r.box) < frame.width*frame.height*0.012) continue;
    if (keep.some(k => iou(k.box,r.box) > 0.48)) continue;
    keep.push(r);
  }
  return keep;
}

function expandedBox(box, pad=.10) {
  const w=box.xmax-box.xmin,h=box.ymax-box.ymin;
  return {
    xmin: Math.max(0, Math.floor(box.xmin-w*pad)),
    ymin: Math.max(0, Math.floor(box.ymin-h*pad)),
    xmax: Math.min(frame.width, Math.ceil(box.xmax+w*pad)),
    ymax: Math.min(frame.height, Math.ceil(box.ymax+h*pad))
  };
}

function cropDataURL(box) {
  const b=expandedBox(box,.12), w=Math.max(1,b.xmax-b.xmin), h=Math.max(1,b.ymax-b.ymin);
  const maxSide=384, scale=Math.min(1,maxSide/Math.max(w,h));
  cropCanvas.width=Math.max(1,Math.round(w*scale));
  cropCanvas.height=Math.max(1,Math.round(h*scale));
  cctx.clearRect(0,0,cropCanvas.width,cropCanvas.height);
  cctx.drawImage(frame,b.xmin,b.ymin,w,h,0,0,cropCanvas.width,cropCanvas.height);
  return cropCanvas.toDataURL("image/jpeg",.82);
}

function mapBox(box) {
  const vw=frame.width,vh=frame.height,rect=video.getBoundingClientRect();
  const videoAspect=vw/vh,viewAspect=rect.width/rect.height;
  let displayW,displayH,offsetX,offsetY;
  if(videoAspect>viewAspect){displayH=rect.height;displayW=displayH*videoAspect;offsetX=(rect.width-displayW)/2;offsetY=0;}
  else{displayW=rect.width;displayH=displayW/videoAspect;offsetX=0;offsetY=(rect.height-displayH)/2;}
  return {x:offsetX+(box.xmin/vw)*displayW,y:offsetY+(box.ymin/vh)*displayH,w:((box.xmax-box.xmin)/vw)*displayW,h:((box.ymax-box.ymin)/vh)*displayH};
}

function drawRows(rows) {
  const rect=video.getBoundingClientRect();
  octx.clearRect(0,0,rect.width,rect.height);
  if(!settings().boxes)return;
  octx.lineWidth=3;octx.font="700 14px system-ui";

  for(const r of rows){
    const b=mapBox(r.box);
    const branded=r.classification?.kind==="brand" && r.classification?.confirmed;
    const generic=r.classification?.kind==="generic";
    const color=branded?"#62d68a":generic?"#ffc85a":"#d9dde2";
    octx.strokeStyle=color;octx.fillStyle=color;octx.strokeRect(b.x,b.y,b.w,b.h);
    const label=r.classification
      ? `${r.classification.display}${branded?" probable":""} ${Math.round(r.classification.score*100)}%`
      : `chaussure ${Math.round(r.score*100)}%`;
    const tw=octx.measureText(label).width+14,ty=Math.max(4,b.y-28);
    octx.fillRect(b.x,ty,tw,24);octx.fillStyle="#09100b";octx.fillText(label,b.x+7,ty+17);
  }
}

async function ensureDetector() {
  if(detector)return detector;
  setState("CHARGEMENT 1/2","détecteur de chaussures");
  detector=await pipeline("zero-shot-object-detection","Xenova/owlvit-base-patch32",{dtype:"q8"});
  return detector;
}

async function ensureClassifier() {
  if(classifier)return classifier;
  setState("CHARGEMENT 2/2","classifieur des crops");
  classifier=await pipeline("zero-shot-image-classification","Xenova/clip-vit-base-patch32",{dtype:"q8"});
  return classifier;
}

async function classifyCrop(row) {
  const classes=classifierCandidates();
  if(classes.length<2)return null;
  const prompts=classes.map(x=>x.prompt), byPrompt=new Map(classes.map(x=>[x.prompt,x]));
  const crop=cropDataURL(row.box);
  const model=await ensureClassifier();
  const output=await model(crop,prompts);
  classifiedTotal++;
  $("classified-count").textContent=classifiedTotal;
  const ranked=output.map(x=>({...x,meta:byPrompt.get(x.label)})).filter(x=>x.meta).sort((a,b)=>b.score-a.score);
  const best=ranked[0],second=ranked[1];
  if(!best)return null;

  const margin=best.score-(second?.score||0);
  const s=settings();
  const confirmedBrand=best.meta.kind==="brand" && best.score>=s.brandThreshold && margin>=s.brandMargin;
  const confirmedGeneric=best.meta.kind==="generic" && best.score>=Math.max(.28,s.brandThreshold-.08) && margin>=Math.max(.025,s.brandMargin*.45);

  return {
    key:best.meta.key,
    display:best.meta.label,
    kind:best.meta.kind,
    score:best.score,
    margin,
    confirmed: confirmedBrand || confirmedGeneric,
    second: second ? {display:second.meta.label,score:second.score} : null
  };
}

function stableConfirm(row) {
  const c=row.classification;
  if(!c?.confirmed)return false;
  const key=`${c.kind}:${c.key}`;
  const next=(streaks.get(key)||0)+1;
  streaks.set(key,next);
  return next>=settings().confirmFrames;
}

function decayStreaks(activeKeys) {
  for(const key of [...streaks.keys()]){
    if(!activeKeys.has(key)) streaks.set(key,Math.max(0,(streaks.get(key)||0)-1));
  }
}

function updateRecent(row) {
  const c=row.classification;if(!c)return;
  recentDetections.unshift({label:c.display,score:c.score,kind:c.kind,confirmed:c.confirmed});
  while(recentDetections.length>9)recentDetections.pop();
  const wrap=$("detections");wrap.innerHTML="";
  if(!recentDetections.length){wrap.innerHTML='<span class="empty-detection">Aucune cible confirmée.</span>';return;}
  recentDetections.forEach(x=>{
    const span=document.createElement("span");
    span.className=`detection-pill ${x.kind==="brand"&&x.confirmed?"brand-confirmed":x.kind==="generic"?"generic":"uncertain"}`;
    span.textContent=`${x.label}${x.kind==="brand"?" probable":""} · ${Math.round(x.score*100)}%`;
    wrap.appendChild(span);
  });
}

function alertRow(row) {
  const c=row.classification;
  if(!c?.confirmed)return;
  if(c.kind==="negative")return;
  if(c.kind==="generic"&&!settings().genericAlert)return;

  const key=`${c.kind}:${c.key}`,now=Date.now();
  if(now-(lastAlerts.get(key)||0)<ALERT_COOLDOWN_MS)return;
  lastAlerts.set(key,now);
  alertTotal++;$("alert-count").textContent=alertTotal;

  const banner=$("alert-banner");
  banner.className=`alert-banner ${c.kind==="brand"?"brand-confirmed":"generic"}`;
  $("alert-kicker").textContent=c.kind==="brand"?"MARQUE PROBABLE":"CHAUSSURE OUTDOOR";
  $("alert-title").textContent=(c.kind==="brand"?`${c.display} probable`:c.display).toUpperCase();
  $("alert-score").textContent=`CLIP ${Math.round(c.score*100)} % · écart ${Math.round(c.margin*100)} pts`;
  banner.classList.remove("hidden");
  beep(c.kind==="brand");vibrate(c.kind==="brand");
  clearTimeout(alertRow.timer);
  alertRow.timer=setTimeout(()=>banner.classList.add("hidden"),1900);
}

async function scanOnce() {
  if(!scanning||paused)return;
  const start=performance.now(),image=captureFrame();
  if(!image)return;

  try{
    const det=await ensureDetector();
    setState("ÉTAPE 1/2","repérage des chaussures");
    const raw=await det(image,["shoe","sneaker","hiking shoe","boot"],{
      threshold:settings().detectorThreshold,
      topk:12
    });

    scanNumber++;
    const boxes=dedupeBoxes(raw.filter(x=>x.box)).slice(0,settings().maxCrops);
    detectionTotal+=boxes.length;$("detection-count").textContent=detectionTotal;

    if(!boxes.length){
      drawRows([]);
      decayStreaks(new Set());
      const ms=Math.round(performance.now()-start);
      $("last-scan").textContent=ms<1000?`${ms} ms`:`${(ms/1000).toFixed(1)} s`;
      setState("RADAR ACTIF",`aucune chaussure · cycle #${scanNumber}`);
      return;
    }

    setState("ÉTAPE 2/2",`${boxes.length} crop(s) à classifier`);
    const rows=[];
    const activeKeys=new Set();

    for(const boxRow of boxes){
      const classification=await classifyCrop(boxRow);
      const row={...boxRow,classification};
      rows.push(row);
      if(classification?.confirmed){
        const key=`${classification.kind}:${classification.key}`;
        activeKeys.add(key);
        if(stableConfirm(row)){updateRecent(row);alertRow(row);}
      }
    }

    decayStreaks(activeKeys);
    drawRows(rows);
    const ms=Math.round(performance.now()-start);
    $("last-scan").textContent=ms<1000?`${ms} ms`:`${(ms/1000).toFixed(1)} s`;
    const branded=rows.filter(x=>x.classification?.kind==="brand"&&x.classification?.confirmed).length;
    setState("RADAR ACTIF",`${boxes.length} chaussure(s) · ${branded} marque(s) probable(s) · #${scanNumber}`);
  }catch(err){
    console.error(err);
    setState("ERREUR IA","connexion, mémoire ou modèle indisponible");
  }
}

function scheduleNext(){
  clearTimeout(scanTimer);
  if(!scanning||paused)return;
  scanTimer=setTimeout(async()=>{await scanOnce();scheduleNext();},settings().interval);
}

async function startRadar(){
  if(!navigator.mediaDevices?.getUserMedia){alert("La caméra web n'est pas disponible dans ce navigateur.");return;}
  await ensureAudio();
  try{
    stream=await navigator.mediaDevices.getUserMedia({
      audio:false,
      video:{facingMode:{ideal:"environment"},width:{ideal:1280},height:{ideal:720}}
    });
    video.srcObject=stream;await video.play();resizeOverlay();
    $("idle-screen").classList.add("hidden");$("topbar").classList.remove("hidden");$("bottom-panel").classList.remove("hidden");

    const track=stream.getVideoTracks()[0],caps=track.getCapabilities?.()||{};
    if(caps.torch)$("torch").classList.remove("hidden");

    scanning=true;paused=false;setState("PRÉPARATION","chargement des deux modèles");
    Promise.all([ensureDetector(),ensureClassifier()]).then(()=>{
      if(!scanning)return;scanOnce().finally(scheduleNext);
    }).catch(err=>{console.error(err);setState("ERREUR IA","chargement des modèles impossible");});
  }catch(err){
    console.error(err);
    alert("Impossible d'ouvrir la caméra. Vérifie l'autorisation caméra et utilise une adresse HTTPS.");
  }
}

function togglePause(){
  paused=!paused;$("pause").textContent=paused?"Reprendre":"Pause";
  if(paused){clearTimeout(scanTimer);setState("EN PAUSE","la caméra reste ouverte",true);}
  else{setState("RADAR ACTIF","reprise");scanOnce().finally(scheduleNext);}
}

async function toggleTorch(){
  const track=stream?.getVideoTracks?.()[0];if(!track)return;
  try{torchOn=!torchOn;await track.applyConstraints({advanced:[{torch:torchOn}]});$("torch").textContent=torchOn?"Lampe ON":"Lampe";}
  catch{torchOn=false;}
}

$("start").addEventListener("click",startRadar);
$("pause").addEventListener("click",togglePause);
$("torch").addEventListener("click",toggleTorch);
$("settings-open").addEventListener("click",()=>$("settings").showModal());

["threshold","brand-threshold","brand-margin","interval"].forEach(id=>{
  $(id).addEventListener("input",()=>{updateSettingLabels();saveSettings();if(id==="interval"&&scanning&&!paused)scheduleNext();});
});
document.querySelectorAll("#settings input, #settings select").forEach(el=>el.addEventListener("change",saveSettings));

window.addEventListener("resize",resizeOverlay);
document.addEventListener("visibilitychange",()=>{
  if(document.hidden&&scanning&&!paused){
    paused=true;$("pause").textContent="Reprendre";clearTimeout(scanTimer);setState("EN PAUSE","application en arrière-plan",true);
  }
});

loadSettings();
